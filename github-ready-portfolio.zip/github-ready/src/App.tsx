import { useEffect } from 'react';
import { motion } from 'framer-motion';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import SkillsSection from './components/SkillsSection';
import ProjectsSection from './components/ProjectsSection';
import TestimonialsSection from './components/TestimonialsSection';
import ContactSection from './components/ContactSection';
import CTASection from './components/CTASection';
import DynamicBackground from './components/DynamicBackground';
import { ThemeProvider, ThemeSwitcher } from './components/ThemeProvider';

function App() {
  useEffect(() => {
    // Smooth scroll behavior
    document.documentElement.style.scrollBehavior = 'smooth';
    
    return () => {
      document.documentElement.style.scrollBehavior = '';
    };
  }, []);

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-black text-white">
        <DynamicBackground />
        <Navbar />
        <main>
          <HeroSection />
          <AboutSection />
          <SkillsSection />
          <ProjectsSection />
          <TestimonialsSection />
          <ContactSection />
          <CTASection />
        </main>
        <footer className="py-8 bg-black/80 backdrop-blur-md border-t border-blue-900/30">
          <div className="container mx-auto px-4 text-center">
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="text-gray-400"
            >
              © {new Date().getFullYear()} Milan Makwana. All rights reserved.
            </motion.p>
          </div>
        </footer>
        <ThemeSwitcher />
      </div>
    </ThemeProvider>
  );
}

export default App;

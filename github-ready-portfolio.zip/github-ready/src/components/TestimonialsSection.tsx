import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const TestimonialsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const testimonials = [
    {
      name: 'Sarah Johnson',
      position: 'Research Director',
      company: 'DataTech Solutions',
      image: '👩‍💼',
      text: 'Milan\'s analytical skills are exceptional. His ability to transform complex data into actionable insights has been invaluable to our research initiatives.',
    },
    {
      name: 'Michael Chen',
      position: 'Chief Data Officer',
      company: 'Insight Analytics',
      image: '👨‍💼',
      text: 'Working with Milan was a game-changer for our data strategy. His research methodology and attention to detail produced results that exceeded our expectations.',
    },
    {
      name: 'Priya Patel',
      position: 'VP of Operations',
      company: 'Global Research Inc.',
      image: '👩‍💻',
      text: 'Milan\'s data expertise helped us identify critical trends that we had overlooked. His research-driven approach delivered measurable improvements to our processes.',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { y: 50, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-b from-black to-blue-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: -20 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold text-white mb-2"
          >
            Client Testimonials
          </motion.h2>
          <motion.div 
            initial={{ opacity: 0, scale: 0 }}
            animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-24 h-1 bg-blue-500 mx-auto mb-6"
          ></motion.div>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-gray-300 text-lg max-w-2xl mx-auto"
          >
            What clients and colleagues say about my work and collaboration experience.
          </motion.p>
        </div>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ y: -10, transition: { duration: 0.3 } }}
              className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 backdrop-blur-sm rounded-xl p-6 border border-blue-800/30 shadow-xl relative"
            >
              <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-2xl">
                {testimonial.image}
              </div>
              
              <div className="pt-8 text-center">
                <p className="text-gray-300 italic mb-6">"{testimonial.text}"</p>
                <h4 className="text-white font-semibold">{testimonial.name}</h4>
                <p className="text-blue-400 text-sm">{testimonial.position}</p>
                <p className="text-gray-400 text-xs">{testimonial.company}</p>
              </div>
              
              <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2">
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 40L0 20L20 0L40 20L20 40Z" fill="#3B82F6" fillOpacity="0.2" />
                </svg>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default TestimonialsSection;

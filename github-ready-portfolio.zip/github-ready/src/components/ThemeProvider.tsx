import { useState, useEffect } from 'react';

// Define theme types
type ThemeColor = 'blue' | 'purple' | 'teal' | 'indigo';

// Theme color configurations
const themeColors = {
  blue: {
    primary: 'from-blue-600 to-blue-500',
    secondary: 'from-blue-900 to-blue-800',
    accent: 'text-blue-400',
    button: 'bg-blue-600 hover:bg-blue-700',
    border: 'border-blue-500',
    gradient: 'from-blue-900 via-purple-900 to-black',
  },
  purple: {
    primary: 'from-purple-600 to-purple-500',
    secondary: 'from-purple-900 to-purple-800',
    accent: 'text-purple-400',
    button: 'bg-purple-600 hover:bg-purple-700',
    border: 'border-purple-500',
    gradient: 'from-purple-900 via-blue-900 to-black',
  },
  teal: {
    primary: 'from-teal-600 to-teal-500',
    secondary: 'from-teal-900 to-teal-800',
    accent: 'text-teal-400',
    button: 'bg-teal-600 hover:bg-teal-700',
    border: 'border-teal-500',
    gradient: 'from-teal-900 via-blue-900 to-black',
  },
  indigo: {
    primary: 'from-indigo-600 to-indigo-500',
    secondary: 'from-indigo-900 to-indigo-800',
    accent: 'text-indigo-400',
    button: 'bg-indigo-600 hover:bg-indigo-700',
    border: 'border-indigo-500',
    gradient: 'from-indigo-900 via-purple-900 to-black',
  },
};

// Create a context to manage theme
import { createContext, useContext } from 'react';

interface ThemeContextType {
  currentTheme: ThemeColor;
  setTheme: (theme: ThemeColor) => void;
  colors: typeof themeColors.blue;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [currentTheme, setCurrentTheme] = useState<ThemeColor>('blue');
  
  // Function to change theme
  const setTheme = (theme: ThemeColor) => {
    setCurrentTheme(theme);
    localStorage.setItem('portfolio-theme', theme);
  };
  
  // Load theme from localStorage on initial render
  useEffect(() => {
    const savedTheme = localStorage.getItem('portfolio-theme') as ThemeColor;
    if (savedTheme && Object.keys(themeColors).includes(savedTheme)) {
      setCurrentTheme(savedTheme);
    }
  }, []);
  
  const colors = themeColors[currentTheme];
  
  return (
    <ThemeContext.Provider value={{ currentTheme, setTheme, colors }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Custom hook to use theme
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// Theme switcher component
export const ThemeSwitcher = () => {
  const { currentTheme, setTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  
  const themes: ThemeColor[] = ['blue', 'purple', 'teal', 'indigo'];
  
  return (
    <div className="fixed bottom-6 right-6 z-50">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-12 h-12 rounded-full bg-gray-900 border border-gray-700 flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
      >
        <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
        </svg>
      </button>
      
      {isOpen && (
        <div className="absolute bottom-16 right-0 bg-gray-900 border border-gray-700 rounded-lg p-3 shadow-xl">
          <div className="flex flex-col space-y-2">
            {themes.map((theme) => (
              <button
                key={theme}
                onClick={() => {
                  setTheme(theme);
                  setIsOpen(false);
                }}
                className={`w-10 h-10 rounded-full ${
                  theme === 'blue' ? 'bg-blue-500' :
                  theme === 'purple' ? 'bg-purple-500' :
                  theme === 'teal' ? 'bg-teal-500' :
                  'bg-indigo-500'
                } ${
                  currentTheme === theme ? 'ring-2 ring-white' : ''
                } hover:scale-110 transition-transform`}
                aria-label={`Switch to ${theme} theme`}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ThemeProvider;

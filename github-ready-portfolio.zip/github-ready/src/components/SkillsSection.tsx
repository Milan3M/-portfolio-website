import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const SkillsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  const skills = [
    { name: 'Data Analysis', level: 90, color: 'from-blue-500 to-blue-600' },
    { name: 'Research Methods', level: 85, color: 'from-purple-500 to-purple-600' },
    { name: 'Statistical Modeling', level: 80, color: 'from-indigo-500 to-indigo-600' },
    { name: 'Data Visualization', level: 85, color: 'from-cyan-500 to-cyan-600' },
    { name: 'Machine Learning', level: 75, color: 'from-teal-500 to-teal-600' },
    { name: 'SQL & Database Management', level: 85, color: 'from-blue-400 to-blue-500' },
  ];

  const tools = [
    { name: 'Python', icon: '🐍' },
    { name: 'R', icon: 'R' },
    { name: 'Tableau', icon: '📊' },
    { name: 'SQL', icon: '🗃️' },
    { name: 'Excel', icon: '📈' },
    { name: 'Power BI', icon: '⚡' },
    { name: 'SPSS', icon: '📉' },
    { name: 'Jupyter', icon: '📓' },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5, ease: "easeOut" }
    }
  };

  return (
    <section id="skills" className="py-20 bg-gradient-to-b from-blue-950 to-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: -20 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold text-white mb-2"
          >
            My Skills & Expertise
          </motion.h2>
          <motion.div 
            initial={{ opacity: 0, scale: 0 }}
            animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="w-24 h-1 bg-blue-500 mx-auto mb-6"
          ></motion.div>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : { opacity: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-gray-300 text-lg max-w-2xl mx-auto"
          >
            Specialized in transforming complex data into actionable insights through
            advanced analytical techniques and research methodologies.
          </motion.p>
        </div>

        <div ref={ref} className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Skills Bars */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={isInView ? "visible" : "hidden"}
            className="space-y-6"
          >
            <motion.h3 
              variants={itemVariants}
              className="text-2xl font-semibold text-white mb-6"
            >
              Technical Proficiency
            </motion.h3>
            
            {skills.map((skill, index) => (
              <motion.div 
                key={index}
                variants={itemVariants}
                className="space-y-2"
              >
                <div className="flex justify-between">
                  <span className="text-gray-300">{skill.name}</span>
                  <span className="text-gray-400">{skill.level}%</span>
                </div>
                <div className="h-3 w-full bg-gray-700 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={isInView ? { width: `${skill.level}%` } : { width: 0 }}
                    transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                    className={`h-full rounded-full bg-gradient-to-r ${skill.color}`}
                  ></motion.div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Tools & Technologies */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate={isInView ? "visible" : "hidden"}
            className="space-y-6"
          >
            <motion.h3 
              variants={itemVariants}
              className="text-2xl font-semibold text-white mb-6"
            >
              Tools & Technologies
            </motion.h3>
            
            <motion.div 
              variants={itemVariants}
              className="grid grid-cols-2 sm:grid-cols-4 gap-4"
            >
              {tools.map((tool, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="bg-blue-900/30 border border-blue-800/50 rounded-lg p-4 flex flex-col items-center justify-center text-center h-32"
                >
                  <span className="text-3xl mb-2">{tool.icon}</span>
                  <span className="text-gray-300 font-medium">{tool.name}</span>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;

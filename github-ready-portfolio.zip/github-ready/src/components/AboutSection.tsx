import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.8, ease: "easeOut" }
    }
  };

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-black to-blue-950">
      <div className="container mx-auto px-4">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center"
        >
          <motion.div variants={itemVariants} className="relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl opacity-75 blur-lg"></div>
            <div className="relative bg-gray-900 p-6 rounded-lg shadow-2xl">
              <div className="aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center">
                <svg className="w-32 h-32 text-blue-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd"></path>
                </svg>
              </div>
              <div className="mt-6 space-y-2">
                <div className="h-2 bg-gray-700 rounded-full w-3/4"></div>
                <div className="h-2 bg-gray-700 rounded-full"></div>
                <div className="h-2 bg-gray-700 rounded-full w-5/6"></div>
              </div>
            </div>
          </motion.div>

          <div className="space-y-8">
            <motion.div variants={itemVariants}>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">About Me</h2>
              <div className="w-20 h-1 bg-blue-500 mb-6"></div>
              <p className="text-gray-300 text-lg leading-relaxed">
                I'm Milan Makwana, a dedicated Data Associate with expertise in data analysis and research. 
                My passion lies in transforming complex data into meaningful insights that drive decision-making.
              </p>
            </motion.div>

            <motion.div variants={itemVariants}>
              <p className="text-gray-300 text-lg leading-relaxed">
                With a strong foundation in data methodologies and research techniques, I specialize in 
                uncovering patterns and trends that others might miss. My analytical approach combined with 
                attention to detail allows me to deliver comprehensive and accurate results.
              </p>
            </motion.div>

            <motion.div variants={itemVariants} className="grid grid-cols-2 gap-4">
              <div className="bg-blue-900/30 p-4 rounded-lg border border-blue-800">
                <h3 className="text-xl font-semibold text-white mb-2">Experience</h3>
                <p className="text-gray-300">5+ Years</p>
              </div>
              <div className="bg-blue-900/30 p-4 rounded-lg border border-blue-800">
                <h3 className="text-xl font-semibold text-white mb-2">Projects</h3>
                <p className="text-gray-300">50+ Completed</p>
              </div>
            </motion.div>

            <motion.div variants={itemVariants}>
              <button className="px-6 py-3 bg-transparent border-2 border-blue-500 text-blue-400 rounded-full font-medium hover:bg-blue-500/10 transition-colors flex items-center gap-2">
                Download Resume
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
              </button>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
